<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConfigProduct extends Model
{
    //
}
