<div id="carouselExampleCaptions_<?php echo e($id); ?>" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <?php if($gallery): ?>
            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li data-target="#carousel-example-1z" style="background-color: darkgray;" data-slide-to="<?php echo e($k); ?>" class="<?php echo e($k == 0 ? 'active' : null); ?>" ></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </ol>
    <div class="carousel-inner">
        <?php if($gallery): ?>

            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($k == 0 ? 'active' : null); ?> text-center">
                    <img class="img-fluid" style=" " src="<?php echo asset($item{'image'}); ?>"
                         alt="First slide">
                    <?php if($item{'title_'.App::getLocale()}): ?>
                    <div class="carousel-caption d-none d-md-block">
                        <span class="bg-dark text-white px-3"><?php echo $item{'title_'.App::getLocale()}; ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleCaptions_<?php echo e($id); ?>" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleCaptions_<?php echo e($id); ?>" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/components/gallery.blade.php ENDPATH**/ ?>