<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('productos.index',['general' => $general])); ?>"><< Volver</a>
        <form class="mb-5" method="POST" action="<?php echo e(route('productos.update',$producto->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <input type="text" class="d-none" name="general_id" value="<?php echo e($general->id); ?>">

            
            <?php if($general->id == 1): ?>
                <div class="row">
                    <div class="col-md-6 mt-4">
                        <p>Seleccionar Categoria</p>

                        <select class="custom-select form-control select2" name="category_id">
                            <option value="">Ninguno</option>
                            <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo $item->id; ?>" <?php echo e($item->id == $producto->family_id ? 'selected' : null); ?>><?php echo $item->text{'title_es'}; ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option value="" selected disabled>No hay registros</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mt-4">
                        <p>Seleccionar Subcategoria</p>
                        <select class="custom-select form-control select2" name="subcategory_id">
                            <option value="">Ninguno</option>
                            <?php $__empty_1 = true; $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo $item->id; ?>" <?php echo e($item->id == $producto->subfamily_id ? 'selected' : null); ?>><?php echo $item->text{'title_es'}; ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option value="" selected disabled>No hay registros</option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
            <div class="row">
                <div class="md-form col-md-6">
                    <input type="text" id="title_es" name="title_es" value="<?php echo $producto->text{'title_es'} ?? ''; ?>" placeholder="Titulo - español" class="form-control">
                </div>
                <div class="md-form col-md-6">
                    <input type="text" id="title_en" name="title_en" value="<?php echo $producto->text{'title_en'} ?? ''; ?>" placeholder="Titulo - ingles" class="form-control">
                </div>
                <div class="md-form col-md-6">
                    <input type="text" id="subtitle_es" name="subtitle_es" value="<?php echo $producto->text{'subtitle_es'} ?? ''; ?>" placeholder="Subtitulo - español" class="form-control">
                </div>
                <div class="md-form col-md-6">
                    <input type="text" id="subtitle_en" name="subtitle_en" value="<?php echo $producto->text{'subtitle_en'} ?? ''; ?>" placeholder="Subtitulo - ingles" class="form-control">
                </div>
            </div>
            <div class="row">
                <div class="md-form col-md-6">
                    <h6>Texto - español</h6>
                    <textarea id="text_es" class="md-textarea form-control" name="text_es" rows="3"><?php echo $producto->text{'text_es'} ?? ''; ?></textarea>
                </div>
                <div class="md-form col-md-6">
                    <h6>Texto - ingles</h6>
                    <textarea id="text_en" class="md-textarea form-control" name="text_en" rows="3"><?php echo $producto->text{'text_en'} ?? ''; ?></textarea>
                </div>
            </div>
            <div class="row">
                <div class="md-form m-0 col-md-6">
                    <input type="text" id="titlec_es" name="titlec_es" value="<?php echo $producto->text{'titlec_es'} ?? ''; ?>" placeholder="Titulo Caracteristicas - español" class="form-control">
                </div>
                <div class="md-form m-0 col-md-6">
                    <input type="text" id="titlec_en" name="titlec_en" value="<?php echo $producto->text{'titlec_en'} ?? ''; ?>" placeholder="Titulo Caracteristicas - ingles" class="form-control">
                </div>
                <div class="md-form col-md-6">
                    <h6>Caracteristicas - español</h6>
                    <textarea id="caracteristica_es" class="md-textarea form-control" name="caracteristica_es" rows="3"><?php echo $producto->text{'caracteristica_es'} ?? ''; ?></textarea>
                </div>
                <div class="md-form col-md-6">
                    <h6>Caracteristicas - ingles</h6>
                    <textarea id="caracteristica_en" class="md-textarea form-control" name="caracteristica_en" rows="3"><?php echo $producto->text{'caracteristica_en'} ?? ''; ?></textarea>
                </div>
            </div>
            <div class="row">
                <div class="md-form m-0 col-md-6">
                    <input type="text" id="titlet_es" name="titlet_es" value="<?php echo $producto->text{'titlet_es'} ?? ''; ?>" placeholder="Titulo Tabla - español" class="form-control">
                </div>
                <div class="md-form m-0 col-md-6">
                    <input type="text" id="titlet_en" name="titlet_en" value="<?php echo $producto->text{'titlet_en'} ?? ''; ?>" placeholder="Titulo Tabla - ingles" class="form-control">
                </div>
                <div class="md-form col-md-6">
                    <h6>Tabla - español</h6>
                    <textarea id="tabla_es" class="md-textarea form-control" name="tabla_es" rows="3"><?php echo $producto->text{'tabla_es'} ?? ''; ?></textarea>
                </div>
                <div class="md-form col-md-6">
                    <h6>Tabla - ingles</h6>
                    <textarea id="tabla_en" class="md-textarea form-control" name="tabla_en" rows="3"><?php echo $producto->text{'tabla_en'} ?? ''; ?></textarea>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="custom-file ">
                        <input type="file" class="custom-file-input" id="customFileLang" name="ficha_es" lang="es">
                        <label class="custom-file-label" for="customFileLang" data-browse="Subir">Ficha Tecnica - español</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="customFileLang" name="ficha_en" lang="es">
                        <label class="custom-file-label" for="customFileLang" data-browse="Subir">Ficha Tecnica - ingles</label>
                    </div>
                </div>
                <div class="md-form input-group col-md-8">
                    <div class="input-group-prepend">
                        <span class="input-group-text md-addon" id="material-addon3">Video URL : https://www.youtube.com/watch?v=</span>
                    </div>
                    <input type="text" class="form-control" name="video" value="<?php echo $producto->text{'video'} ?? ''; ?>" placeholder="L5817RH26ZM" aria-describedby="material-addon3">
                </div>
                <div class="md-form col-md-4">
                    <input type="text" id="order" name="order" value="<?php echo $producto->order ?? ''; ?>" placeholder="Orden" class="form-control m-0">
                </div>
                
                
                
                
                
                

            </div>

                <gallery-component :galeria="<?php echo e(json_encode($producto->image)); ?>"></gallery-component>



                <config-component :dosificaciones="<?php echo e(json_encode($dosificadoras)); ?>"></config-component>
            <?php endif; ?>

            
            <?php if($general->id == 2): ?>
                <div class="row">
                    <div class="col-md-6 mt-4">
                        <p>Seleccionar Categoria</p>

                        <select class="custom-select form-control select2" name="category_id">
                            <option value="">Ninguno</option>
                            <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo $item->id; ?>" <?php echo e($item->id == $producto->family_id ? 'selected' : null); ?>><?php echo $item->text{'title_es'}; ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option value="" selected disabled>No hay registros</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6 mt-4">
                        <p>Seleccionar Subcategoria</p>
                        <select class="custom-select form-control select2" name="subcategory_id">
                            <option value="">Ninguno</option>
                            <?php $__empty_1 = true; $__currentLoopData = $subcategorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo $item->id; ?>" <?php echo e($item->id == $producto->subfamily_id ? 'selected' : null); ?>><?php echo $item->text{'title_es'}; ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option value="" selected disabled>No hay registros</option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="md-form col-md-6">
                        <input type="text" id="title_es" name="title_es" value="<?php echo $producto->text{'title_es'} ?? ''; ?>" placeholder="Titulo - español" class="form-control">
                    </div>
                    <div class="md-form col-md-6">
                        <input type="text" id="title_en" name="title_en" value="<?php echo $producto->text{'title_en'} ?? ''; ?>" placeholder="Titulo - ingles" class="form-control">
                    </div>
                </div>
                <div class="row">
                    <div class="md-form col-md-6">
                        <h6>Texto - español</h6>
                        <textarea id="text_es" class="md-textarea form-control" name="text_es" rows="3"><?php echo $producto->text{'text_es'} ?? ''; ?></textarea>
                    </div>
                    <div class="md-form col-md-6">
                        <h6>Texto - ingles</h6>
                        <textarea id="text_en" class="md-textarea form-control" name="text_en" rows="3"><?php echo $producto->text{'text_en'} ?? ''; ?></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="md-form m-0 col-md-6">
                        <input type="text" id="titlec_es" name="titlep_es" value="<?php echo $producto->text{'titlep_es'} ?? ''; ?>" placeholder="Titulo Planos - español" class="form-control">
                    </div>
                    <div class="md-form m-0 col-md-6">
                        <input type="text" id="titlec_en" name="titlep_en" value="<?php echo $producto->text{'titlep_en'} ?? ''; ?>" placeholder="Titulo Planos - ingles" class="form-control">
                    </div>
                    <planos-component :galeria="<?php echo e(json_encode($producto->planos)); ?>"></planos-component>
                    
                        
                        
                    
                    
                        
                        
                    
                </div>
                <div class="row mt-4">
                    <div class="md-form m-0 col-md-6">
                        <input type="text" id="titlet_es" name="titlet_es" value="<?php echo $producto->text{'titlet_es'} ?? ''; ?>" placeholder="Titulo Tabla - español" class="form-control">
                    </div>
                    <div class="md-form m-0 col-md-6">
                        <input type="text" id="titlet_en" name="titlet_en" value="<?php echo $producto->text{'titlet_en'} ?? ''; ?>" placeholder="Titulo Tabla - ingles" class="form-control">
                    </div>
                    <div class="md-form col-md-6">
                        <h6>Tabla - español</h6>
                        <textarea id="tabla_es" class="md-textarea form-control" name="tabla_es" rows="3"><?php echo $producto->text{'tabla_es'} ?? ''; ?></textarea>
                    </div>
                    <div class="md-form col-md-6">
                        <h6>Tabla - ingles</h6>
                        <textarea id="tabla_en" class="md-textarea form-control" name="tabla_en" rows="3"><?php echo $producto->text{'tabla_en'} ?? ''; ?></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="custom-file ">
                            <input type="file" class="custom-file-input" id="customFileLang" name="ficha_es" lang="es">
                            <label class="custom-file-label" for="customFileLang" data-browse="Subir">Ficha Tecnica - español</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="customFileLang" name="ficha_en" lang="es">
                            <label class="custom-file-label" for="customFileLang" data-browse="Subir">Ficha Tecnica - ingles</label>
                        </div>
                    </div>
                    <div class="md-form input-group col-md-8">
                        <div class="input-group-prepend">
                            <span class="input-group-text md-addon" id="material-addon3">Video URL : https://www.youtube.com/watch?v=</span>
                        </div>
                        <input type="text" class="form-control" name="video" value="<?php echo $producto->text{'video'} ?? ''; ?>" placeholder="L5817RH26ZM" aria-describedby="material-addon3">
                    </div>
                    <div class="md-form col-md-4">
                        <input type="text" id="order" name="order" value="<?php echo $producto->order ?? ''; ?>" placeholder="Orden" class="form-control m-0">
                    </div>
                </div>
                
                <select-component :envasadoras="<?php echo e(json_encode($envasadoras)); ?>" :selectedenvasadoras="<?php echo e(json_encode($producto->related)); ?>" :accesorios="<?php echo e(json_encode($accesorios)); ?>" :selectedaccesorios="<?php echo e(json_encode($producto->related_accesorio)); ?>"></select-component>
                
                <gallery-component :galeria="<?php echo e(json_encode($producto->image)); ?>"></gallery-component>
            <?php endif; ?>

            
            <?php if($general->id == 3): ?>
                <div class="row">
                    <div class="md-form col-md-6">
                        <input type="text" id="title_es" name="title_es" value="<?php echo $producto->text{'title_es'} ?? ''; ?>" placeholder="Titulo - español" class="form-control">
                    </div>
                    <div class="md-form col-md-6">
                        <input type="text" id="title_en" name="title_en" value="<?php echo $producto->text{'title_en'} ?? ''; ?>" placeholder="Titulo - ingles" class="form-control">
                    </div>
                </div>
                <div class="row">
                    <div class="md-form col-md-6">
                        <h6>Texto - español</h6>
                        <textarea id="text_es" class="md-textarea form-control" name="text_es" rows="3"><?php echo $producto->text{'text_es'} ?? ''; ?></textarea>
                    </div>
                    <div class="md-form col-md-6">
                        <h6>Texto - ingles</h6>
                        <textarea id="text_en" class="md-textarea form-control" name="text_en" rows="3"><?php echo $producto->text{'text_en'} ?? ''; ?></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="md-form m-0 col-md-6">
                        <input type="text" id="titlec_es" name="titlec_es" value="<?php echo $producto->text{'titlec_es'} ?? ''; ?>" placeholder="Titulo Caracteristicas - español" class="form-control">
                    </div>
                    <div class="md-form m-0 col-md-6">
                        <input type="text" id="titlec_en" name="titlec_en" value="<?php echo $producto->text{'titlec_en'} ?? ''; ?>" placeholder="Titulo Caracteristicas - ingles" class="form-control">
                    </div>
                    <div class="md-form col-md-6">
                        <h6>Caracteristicas - español</h6>
                        <textarea id="caracteristica_es" class="md-textarea form-control" name="caracteristica_es" rows="3"><?php echo $producto->text{'caracteristica_es'} ?? ''; ?></textarea>
                    </div>
                    <div class="md-form col-md-6">
                        <h6>Caracteristicas - ingles</h6>
                        <textarea id="caracteristica_en" class="md-textarea form-control" name="caracteristica_en" rows="3"><?php echo $producto->text{'caracteristica_en'} ?? ''; ?></textarea>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="md-form m-0 col-md-6">
                        <input type="text" id="titlet_es" name="titlet_es" value="<?php echo $producto->text{'titlet_es'} ?? ''; ?>" placeholder="Titulo Tabla - español" class="form-control">
                    </div>
                    <div class="md-form m-0 col-md-6">
                        <input type="text" id="titlet_en" name="titlet_en" value="<?php echo $producto->text{'titlet_en'} ?? ''; ?>" placeholder="Titulo Tabla - ingles" class="form-control">
                    </div>
                    <div class="md-form col-md-6">
                        <h6>Tabla - español</h6>
                        <textarea id="tabla_es" class="md-textarea form-control" name="tabla_es" rows="3"><?php echo $producto->text{'tabla_es'} ?? ''; ?></textarea>
                    </div>
                    <div class="md-form col-md-6">
                        <h6>Tabla - ingles</h6>
                        <textarea id="tabla_en" class="md-textarea form-control" name="tabla_en" rows="3"><?php echo $producto->text{'tabla_en'} ?? ''; ?></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="custom-file ">
                            <input type="file" class="custom-file-input" id="customFileLang" name="ficha_es" lang="es">
                            <label class="custom-file-label" for="customFileLang" data-browse="Subir">Ficha Tecnica - español</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="customFileLang" name="ficha_en" lang="es">
                            <label class="custom-file-label" for="customFileLang" data-browse="Subir">Ficha Tecnica - ingles</label>
                        </div>
                    </div>
                    <div class="md-form input-group col-md-8">
                        <div class="input-group-prepend">
                            <span class="input-group-text md-addon" id="material-addon3">Video URL : https://www.youtube.com/watch?v=</span>
                        </div>
                        <input type="text" class="form-control" name="video" value="<?php echo $producto->text{'video'} ?? ''; ?>" placeholder="L5817RH26ZM" aria-describedby="material-addon3">
                    </div>
                    <div class="md-form col-md-4">
                        <input type="text" id="order" name="order" value="<?php echo $producto->order ?? ''; ?>" placeholder="Orden" class="form-control m-0">
                    </div>
                </div>
                
                
                
                <gallery-component :galeria="<?php echo e(json_encode($producto->image)); ?>"></gallery-component>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-12 text-right">
                    <button type="submit" class="btn btn-success">Guardar</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        /*$(document).ready(function() {
            $('.select2').select2();
        });*/

        CKEDITOR.replace('text_es');
        CKEDITOR.replace('text_en');
        CKEDITOR.replace('tabla_en');
        CKEDITOR.replace('tabla_es');
        CKEDITOR.replace('caracteristica_es');
        CKEDITOR.replace('caracteristica_en');
        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/adm/products/edit.blade.php ENDPATH**/ ?>