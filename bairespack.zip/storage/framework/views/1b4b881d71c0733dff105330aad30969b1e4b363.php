<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('page.partials.carousel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($contenido): ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8">
                <h2 class="py-2" ><?php echo $contenido->text{'title_'.App::getLocale()}; ?></h2>
                <hr align="left" class="w-25" style="border-top: 2px solid #FEB80B;">
                <p class="">
                    <?php echo $contenido->text{'text_'.App::getLocale()}; ?>

                </p>
            </div>
            <div class="col-md-4">
                <img src="<?php echo e(asset($contenido->text{'image'})); ?>" alt="" class="img-fluid">
            </div>
        </div>
    </div>
    <div class="container my-4">
        <div class="row">
            <div class="col-md-6">
                <div class="p-4" style="background-color: #f2f2f2">
                    <h2 class="baires-color"><?php echo $contenido->text{'mision_'.App::getLocale()}; ?></h2>
                    <?php echo $contenido->text{'misiontext_'.App::getLocale()}; ?>

                </div>
            </div>
            <div class="col-md-6 " >
                <div class="p-4" style="background-color: #f2f2f2">
                    <h2 class="baires-color"><?php echo $contenido->text{'valores_'.App::getLocale()}; ?></h2>
                    <?php echo $contenido->text{'valorestext_'.App::getLocale()}; ?>

                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/page/nosotros.blade.php ENDPATH**/ ?>