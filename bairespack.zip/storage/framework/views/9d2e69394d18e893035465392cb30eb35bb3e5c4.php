<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('categoria.index')); ?>"><< Volver</a>
        <form class="row" method="POST" action="<?php echo e(route('categoria.update',$category->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="md-form col-md-6">
                <input type="text" id="title_es" name="title_es" value="<?php echo $category->text{'title_es'}; ?>"  placeholder="Titulo - español" class="form-control">
            </div>
            <div class="md-form col-md-6">
                <input type="text" id="title_en" name="title_en" value="<?php echo $category->text{'title_en'}; ?>"  placeholder="Titulo - ingles" class="form-control">
            </div>
            <div class="col-md-4">
                <div class="md-form">
                    <input type="text" id="order" name="order" class="form-control" value="<?php echo $category->order; ?>">
                    <label for="order" class="">Orden</label>
                </div>
            </div>
            <div class="col-md-12 my-4 text-right">
                <button type="submit" class="btn btn-success">Guardar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        CKEDITOR.replace('subtitle');

        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/adm/category/edit.blade.php ENDPATH**/ ?>