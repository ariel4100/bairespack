
                <div class="card shadow-none">
                    <?php if(isset($item->image[0]['image'])): ?>
                        <div class="card-body justify-content-center d-flex align-items-center" style="height: <?php echo e($height ?? 'auto'); ?>;">
                            <img class="img-fluid" src="<?php echo e(asset($item->image[0]['image'] ?? '')); ?>" alt="Card image cap">
                        </div>
                    <?php endif; ?>
                    <?php if(isset($item->text{'image'})): ?>
                        <div class="card-body justify-content-center d-flex align-items-center" style="height: <?php echo e($height ?? 'auto'); ?>;">
                            <img class="img-fluid" src="<?php echo e(asset($item->text{'image'} ?? '')); ?>" alt="Card image cap">
                        </div>
                    <?php endif; ?>
                    <div class="card-footer bg-white <?php echo e($style ?? ''); ?>">
                        <?php if(isset($item->general->text)): ?>
                            <p class="m-0"><?php echo $item->general->text{'title_'.App::getLocale()} ?? ''; ?></p>
                        <?php endif; ?>
                        <?php if(isset($item->subfamily->text)): ?>
                            <p class="m-0"><?php echo $item->subfamily->text{'title_'.App::getLocale()} ?? ''; ?></p>
                        <?php endif; ?>
                        <?php if(isset($item->general)): ?>
                            <h4 class="">
                                <?php echo $item->text{'title_'.App::getLocale()} ?? ''; ?>

                            </h4>
                        <?php else: ?>
                            <p class="m-0">
                                <?php echo $item->text{'title_'.App::getLocale()} ?? ''; ?>

                            </p>
                        <?php endif; ?>
                        <h4 class="">
                            <?php echo $item->text{'subtitle_'.App::getLocale()} ?? ''; ?>

                        </h4>
                    </div>
                </div>



    
        
        
            
                
                    
                        
                            
                        
                    
                    
                        
                            
                        
                    
                    
                        
                            
                        
                        
                            
                        
                        
                            
                        
                        
                            
                        
                    
                
            
        
    
<?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/components/card.blade.php ENDPATH**/ ?>