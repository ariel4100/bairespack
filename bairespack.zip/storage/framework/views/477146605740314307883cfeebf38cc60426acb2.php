<?php $__env->startSection('content'); ?>

<div class="container" style="margin-top: 8rem">
    <h2 class="text-uppercase">Noticias</h2>
    <hr align="left" class="" style="border-top: 2px solid #FEB80B; width: 150px">
    <div class="row my-5">
        <div class="col-md-8">
            <!--Carousel Wrapper-->
            <div id="carousel-example-1z" class="carousel slide carousel-fade" data-ride="carousel">
                <!--Indicators-->
                <ol class="carousel-indicators">
                <?php $__empty_1 = true; $__currentLoopData = $news->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li data-target="#carousel-example-1z" data-slide-to="<?php echo e($k); ?>" ></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                </ol>
                <!--/.Indicators-->
                <!--Slides-->
                <div class="carousel-inner" role="listbox">
                    <?php $__empty_1 = true; $__currentLoopData = $news->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="carousel-item <?php echo e($k==0 ? 'active' : ''); ?>">
                        <img class="d-block w-100" src="<?php echo asset($item{'image'}); ?>"
                             alt="First slide">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?>
                </div>
                <a class="carousel-control-prev" href="#carousel-example-1z" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carousel-example-1z" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            <!--/.Carousel Wrapper-->
            <h5>
                <span class="p-2 my-3 text-uppercase font-weight-bold badge baires-fondo"><?php echo $news->Category->text{'title_'.App::getLocale()}; ?></span>
            </h5>
            <h3 class="mb-4 font-weight-bold"><?php echo $news->text{'title_'.App::getLocale()}; ?></h3>
            <div style="/*font-family: Montserrat Light;*/">
                <?php echo $news->text{'text_'.App::getLocale()}; ?>

            </div>
        </div>
        <div class="col-md-4 ">
            <div class="p-5" style="background-color: #F9F9F9">
                <h5 class="text-uppercase">Categorías</h5>
                <hr align="left" class="" style="background-color: #595959; width: 70px">
                <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <p class="m-0"><a href="<?php echo e(route('show_noticias',$c->id)); ?>" class="" style="text-decoration: none; color: unset;"> <?php echo $c->text{'title_es'}; ?></a></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No hay registros</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/page/noticias/noticias_blog.blade.php ENDPATH**/ ?>