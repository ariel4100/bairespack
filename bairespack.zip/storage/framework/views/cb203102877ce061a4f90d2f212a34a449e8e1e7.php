<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('usuario.index')); ?>"><< Volver</a>
        <form class="" method="POST" action="<?php echo e(route('usuario.update',$usuario->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                <div class="col-md-6">
                    <div class="md-form">
                        <input type="text" id="name" name="name" class="form-control" value="<?php echo $usuario->name; ?>">
                        <label for="name" class="">Nombre</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="md-form">
                        <input type="text" id="username" name="username" class="form-control" required value="<?php echo $usuario->username; ?>">
                        <label for="username" class="">Nombre de Usuario</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="md-form">
                        <input type="email" id="email" name="email" class="form-control" value="<?php echo $usuario->email; ?>" required>
                        <label for="email" class="">Email</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="md-form">
                        <input type="password" id="password" name="password" class="form-control" required>
                        <label for="password" class="">Contraseña</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 my-4 text-right">
                    <button type="submit" class="btn btn-success">Guardar</button>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    
        

        
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/adm/users/edit.blade.php ENDPATH**/ ?>