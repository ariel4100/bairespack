<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('slider.list', ['seccion' => $section])); ?>"><< Volver</a>

        <section class=" ">
            <form class="row" method="POST" action="<?php echo e(route('slider.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="section" value="<?php echo e($section); ?>">
                <div class="md-form col-md-12">
                    <input type="text" id="order" name="order" placeholder="Orden" class="form-control" value="">
                </div>
                <div class="md-form col-md-6">
                    <p class="mb-0">Texto Es</p>
                    <textarea id="text_es" class="md-textarea form-control" name="text_es" rows="3"> </textarea>
                </div>

                <div class="md-form col-md-6">
                    <p class="mb-0">Texto En</p>
                    <textarea id="text_en" class="md-textarea form-control" name="text_en" rows="3"> </textarea>
                </div>
                <div class="col-md-12">
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="customFileLang" name="image" lang="es">
                                <label class="custom-file-label" for="customFileLang">Seleccionar Imagen</label>
                            </div>
                        </div>
                <div class="col-md-12 my-4 text-right">
                    <button type="submit" class="btn btn-success">Guardar</button>
                </div>
            </form>
        </section>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        CKEDITOR.replace('text_es');
        CKEDITOR.replace('text_en');

        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/adm/slider/create.blade.php ENDPATH**/ ?>