<?php $__env->startPush('style'); ?>
    <style>
        #myClassicTab .nav-link{
            color: #000 !important;
        }

            #myClassicTab .nav-link{
                color: #000 !important;
            }
            #myClassicTab li .active{
                border-bottom: 2px solid #FFB900 !important;
            }
            #myClassicTab li a{
                border-bottom: 2px solid #B0B0B0;
            }
        </style>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 8rem">
        
        
        <?php if($general->id == 1): ?>
            <div class="row">
                <div class="col-md-6 border text-center">

                    <?php $__env->startComponent('components.gallery'); ?>
                    <?php $__env->slot('gallery',$producto->image); ?>
                    <?php $__env->slot('id',$producto->id); ?>
                    <?php echo $__env->renderComponent(); ?>

                </div>
                <div class="col-md-6">
                    <h4 class=" "><?php echo $producto->text{'title_'.App::getLocale()} ?? ''; ?></h4>
                    <h4 class="font-weight-bold mb-4 pb-2" style="border-bottom: 2px solid #FFB900"><?php echo $producto->text{'subtitle_'.App::getLocale()} ?? ''; ?></h4>
                    <?php echo $producto->text{'text_'.App::getLocale()} ?? ''; ?>

                    <a href="<?php echo e(route('contacto')); ?>" class="btn baires-fondo rounded-pill m-0 px-4 mb-3" style="width: 35%">Consultar</a>
                    <br>
                    <?php if(isset($producto->text{'file_'.App::getLocale()})): ?>
                    <a href="" class="btn baires-fondo rounded-pill m-0 px-4 mb-3" style="width: 35%">FICHA TÉCNICA</a>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="row my-5 justify-content-end">
                <?php if($producto->text{'titlec_'.App::getLocale()}): ?>
                    <div class="col-md-6">
                        <h5 class="p-3" style="background-color: #F9F9F9"><?php echo $producto->text{'titlec_'.App::getLocale()} ?? ''; ?></h5>
                        <p class=""><?php echo $producto->text{'caracteristica_'.App::getLocale()} ?? ''; ?></p>
                    </div>
                <?php endif; ?>
                <?php if($producto->text{'titlet_'.App::getLocale()}): ?>
                    <div class="col-md-6">
                        <h5 class="p-3" style="background-color: #F9F9F9"><?php echo $producto->text{'titlet_'.App::getLocale()} ?? ''; ?></h5>
                        <?php echo $producto->text{'tabla_'.App::getLocale()} ?? ''; ?>

                    </div>
                <?php endif; ?>
            </div>
            <?php if(isset($producto->text{'video'})): ?>
            <div class="container-fluid " style="background-color: #F9F9F9;">
                <div class="row py-5 align-items-center">
                    <div class="col-md-6">
                        <h3 class="baires-color">Para más información,
                            mirá el video a continuación</h3>
                    </div>
                    <div class="col-md-6">
                        <iframe width="100%" height="250" src="https://www.youtube.com/embed/<?php echo $producto->text{'video'}; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            
            <?php if(count($producto->configuraciones) > 0): ?>
                <h4 class="py-3 text-center my-5" style="background-color: #F9F9F9">Configuraciones</h4>
                <div class="row my-5">
                    <div class="col-md-12">
                        <div class="classic-tabs">
                                <ul class="nav mb-5" id="myClassicTab" role="tablist">
                                    <?php $__empty_1 = true; $__currentLoopData = $producto->configuraciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        
                                        <li class="nav-item">
                                            <a class="nav-link waves-light <?php echo e($k==0 ? 'active': ''); ?> show" id="profile-tab-classic" data-toggle="tab" href="#config-<?php echo e($k); ?>"
                                               role="tab" aria-controls="profile-classic" aria-selected="true"><?php echo $item->text{'tipo_'.App::getLocale()}; ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <li class="nav-item">
                                            <a class="nav-link  waves-light active show" id="profile-tab-classic" data-toggle="tab" href="#config"
                                               role="tab" aria-controls="profile-classic" aria-selected="true">Todos</a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                                <div class="tab-content  " id="myClassicTabContent">
                                    <?php $__currentLoopData = $producto->configuraciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="tab-pane fade <?php echo e($k==0 ? 'active': ''); ?> show" id="config-<?php echo e($k); ?>" role="tabpanel" aria-labelledby="profile-tab-classic">
                                            <div class="row">
                                                <div class="col-md-4 border">
                                                    
                                                    <?php $__env->startComponent('components.gallery'); ?>
                                                    <?php $__env->slot('gallery',$item->image); ?>
                                                    <?php $__env->slot('id',$item->id); ?>
                                                    <?php echo $__env->renderComponent(); ?>
                                                </div>
                                                <div class="col-md-8">
                                                    <h3 class=""><?php echo $item->text{'title_'.App::getLocale()} ?? ''; ?></h3>
                                                    <h4 class=""><?php echo $item->text{'tipo_'.App::getLocale()} ?? ''; ?></h4>
                                                    <p class=""><?php echo $item->text{'text_'.App::getLocale()} ?? ''; ?></p>
                                                    <a href="#modal_<?php echo e($k); ?>" data-toggle="modal"  class="btn baires-fondo rounded-pill m-0 px-5 my-3" >Ingresar</a>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Modal -->
                                        <div class="modal fade <?php echo e(request()->get('config') ? 'show' : ''); ?>" id="modal_<?php echo e($k); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                                             aria-hidden="true">
                                            <div class="modal-dialog modal-lg" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-body">
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                        <div class="row p-5">
                                                            <div class="col-md-6 border">
                                                                <?php $__env->startComponent('components.gallery'); ?>
                                                                <?php $__env->slot('gallery',$item->image); ?>
                                                                <?php $__env->slot('id',$item->order); ?>
                                                                <?php echo $__env->renderComponent(); ?>
                                                            </div>
                                                            <div class="col-md-6">
                                                                <h3 class=""><?php echo $item->text{'title_'.App::getLocale()} ?? ''; ?></h3>
                                                                <h4 class="pb-2" style="border-bottom: 2px solid #FFB900"><?php echo $item->text{'tipo_'.App::getLocale()} ?? ''; ?></h4>
                                                                <p class=""><?php echo $item->text{'text_'.App::getLocale()} ?? ''; ?></p>
                                                                <a href="<?php echo e(route('contacto')); ?>" class="btn baires-fondo rounded-pill m-0  mb-3" style="width: 200px">Consultar</a>
                                                            </div>
                                                            <?php $__empty_1 = true; $__currentLoopData = $item->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dosificadora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <div class="col-md-4 mt-5">
                                                                    <a href="<?php echo e(route('producto',['producto' => $dosificadora->id])); ?>" class=" " style="text-decoration: none; color: unset;">
                                                                        <div class="card shadow-none">
                                                                            <div class="card-body text-center p-0">
                                                                                <img class="img-fluid" src="<?php echo e(asset($dosificadora->image[0]['image'] ?? '')); ?>" alt="Card image cap">
                                                                            </div>
                                                                            <div class="card-footer bg-white">
                                                                                <p class="m-0"><?php echo $dosificadora->text{'title_'.App::getLocale()} ?? ''; ?></p>
                                                                                <h4 class="">
                                                                                    <?php echo $dosificadora->text{'subtitle_'.App::getLocale()} ?? ''; ?>

                                                                                </h4>
                                                                            </div>
                                                                        </div>
                                                                    </a>
                                                                </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>

                            </div>
                    </div>
                </div>
            <?php endif; ?>

        <?php endif; ?>



        
        <?php if($general->id == 2): ?>
            <div class="row">
                <div class="col-md-6 border d-flex justify-content-center align-items-center">
                    <?php $__env->startComponent('components.gallery'); ?>
                    <?php $__env->slot('gallery',$producto->image); ?>
                    <?php $__env->slot('id',$producto->id); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>
                <div class="col-md-6">
                    <h4 class=" "><?php echo $producto->text{'title_'.App::getLocale()} ?? ''; ?></h4>
                    <h4 class="font-weight-bold mb-4 pb-2" style="border-bottom: 2px solid #FFB900"><?php echo $producto->subfamily->text{'title_'.App::getLocale()} ?? ''; ?></h4>
                    <?php echo $producto->text{'text_'.App::getLocale()}; ?>

                    <a href="<?php echo e(route('contacto')); ?>" class="btn baires-fondo rounded-pill m-0 px-4 mb-3" style="width: 35%">Consultar</a>
                    <br>
                    <?php if(isset($producto->text{'file_'.App::getLocale()})): ?>
                        <a href="" class="btn baires-fondo rounded-pill m-0 px-4 mb-3" style="width: 35%">FICHA TÉCNICA</a>
                    <?php endif; ?>
                </div>

            </div>
            
            
            <div class="row my-5 justify-content-end">
                <?php if($producto->text{'titlep_'.App::getLocale()}): ?>
                <div class="col-md-6">
                    <h5 class="p-3" style="background-color: #F9F9F9"><?php echo $producto->text{'titlep_'.App::getLocale()} ?? ''; ?></h5>
                    
                    <?php $__empty_1 = true; $__currentLoopData = $producto->planos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <img src="<?php echo e(asset($planos{'image'})); ?>" alt="" class="img-fluid">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h4>No hay registro</h4>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
                <?php if($producto->text{'titlet_'.App::getLocale()}): ?>
                <div class="col-md-6">
                    <h5 class="p-3" style="background-color: #F9F9F9"><?php echo $producto->text{'titlet_'.App::getLocale()} ?? ''; ?></h5>
                    <?php echo $producto->text{'tabla_'.App::getLocale()} ?? ''; ?>

                </div>
                <?php endif; ?>
            </div>

            <?php if(isset($producto->text{'video'})): ?>
                <div class="container-fluid " style="background-color: #F9F9F9;">
                    <div class="row py-5 align-items-center">
                        <div class="col-md-6">
                            <h3 class="baires-color">Para más información,
                                mirá el video a continuación</h3>
                        </div>
                        <div class="col-md-6">
                            <iframe width="100%" height="250" src="https://www.youtube.com/embed/<?php echo $producto->text{'video'}; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if(count($producto->related) > 0): ?>
            
            <div class="row my-5" style="background-color: #F9F9F9;">
                <div class="col-md-12">
                    <h5 class="text-center py-2 m-0">Máquinas que utilizan esta dosificadora</h5>
                </div>
            </div>
            
            <div class="row my-5">
                <?php $__currentLoopData = $producto->related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-md-3 mb-5">
                        <a href="<?php echo e(route('producto',['producto' => $item->id,'config' => $producto->subfamily->family->text{'title_es'}])); ?>" class=" " style="text-decoration: none; color: unset;">
                            <?php $__env->startComponent('components.card'); ?>
                            <?php $__env->slot('item',$item); ?>
                            <?php $__env->slot('style','text-center'); ?>
                            <?php $__env->slot('height','200px'); ?>
                            <?php echo $__env->renderComponent(); ?>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            
            <?php if(count($producto->related_accesorio) > 0): ?>
            <div class="row my-5" style="background-color: #F9F9F9;">
                <div class="col-md-12">
                    <h5 class="text-center py-2 m-0">Accesorios Relacionados</h5>
                </div>
            </div>
                <div class="row my-5">
                    <?php $__currentLoopData = $producto->related_accesorio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-3 mb-5">
                            <a href="<?php echo e(route('producto',['producto' => $item->id])); ?>" class=" " style="text-decoration: none; color: unset;">


                                <div class="card shadow-none">
                                    <?php if(isset($item->image[0]['image'])): ?>
                                        <div class="card-body justify-content-center d-flex align-items-center" style="height: <?php echo e($height ?? 'auto'); ?>;">
                                            <img class="img-fluid" src="<?php echo e(asset($item->image[0]['image'] ?? '')); ?>" alt="Card image cap">
                                        </div>
                                    <?php endif; ?>
                                    <div class="card-footer bg-white text-center" style="height: 80px">
                                        <h5 class="m-0">
                                            <?php echo $item->text{'title_'.App::getLocale()} ?? ''; ?>

                                        </h5>
                                    </div>
                                </div>

                                
                                
                                
                                
                                
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        
        
        <?php if($general->id == 3): ?>

            <div class="row">
                <div class="col-md-6 border text-center d-flex justify-content-center align-items-center">
                    <?php $__env->startComponent('components.gallery'); ?>
                    <?php $__env->slot('gallery',$producto->image); ?>
                    <?php $__env->slot('id',$producto->id); ?>
                    <?php echo $__env->renderComponent(); ?>
                    
                        
                            
                                
                                    
                                        
                                    
                                
                            
                            
                                
                                    
                                        
                                            
                                                 
                                            
                                                
                                            
                                        
                                    
                                
                            
                            
                                
                                
                            
                            
                                
                                
                            
                        
                    

                </div>
                <div class="col-md-6">
                    <h4 class=" "><?php echo $producto->text{'title_es'} ?? ''; ?></h4>
                    <h4 class="font-weight-bold mb-4 pb-2" style="border-bottom: 2px solid #FFB900"><?php echo $producto->subfamily->text{'title_es'} ?? ''; ?></h4>
                    <?php echo $producto->text{'text_es'} ?? ''; ?>

                    <a href="<?php echo e(route('contacto')); ?>" class="btn baires-fondo rounded-pill m-0 px-4 mb-3" style="width: 200px">Consultar</a>
                    <br>
                    <?php if(isset($producto->text{'file_'.App::getLocale()})): ?>
                        <a href="" class="btn baires-fondo rounded-pill m-0 px-4 mb-3" style="width: 200px">FICHA TÉCNICA</a>
                    <?php endif; ?>
                </div>


            </div>
            
            <div class="row my-5 justify-content-end">
                <?php if($producto->text{'titlec_'.App::getLocale()}): ?>
                <div class="col-md-6">
                    <h5 class="p-3" style="background-color: #F9F9F9"><?php echo $producto->text{'titlec_'.App::getLocale()} ?? ''; ?></h5>
                    <p class=""><?php echo $producto->text{'caracteristica_'.App::getLocale()} ?? ''; ?></p>
                </div>
                <?php endif; ?>
                <?php if($producto->text{'titlet_'.App::getLocale()}): ?>
                <div class="col-md-6">
                    <h5 class="p-3" style="background-color: #F9F9F9"><?php echo $producto->text{'titlet_'.App::getLocale()} ?? ''; ?></h5>
                    <?php echo $producto->text{'tabla_'.App::getLocale()} ?? ''; ?>

                </div>
                <?php endif; ?>
            </div>
            <?php if(isset($producto->text{'video'})): ?>
                <div class="container-fluid " style="background-color: #F9F9F9;">
                    <div class="row py-5 align-items-center">
                        <div class="col-md-6">
                            <h3 class="baires-color">Para más información,
                                mirá el video a continuación</h3>
                        </div>
                        <div class="col-md-6">
                            <iframe width="100%" height="250" src="https://www.youtube.com/embed/<?php echo $producto->text{'video'}; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/page/productos/producto.blade.php ENDPATH**/ ?>