<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 8rem">

        <?php if($general->id == 1): ?>
            <div class="row my-5">
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-md-4 mb-5">
                        <a href="<?php echo e(route('producto',['producto' => $item->id])); ?>" class=" " style="text-decoration: none; color: unset;">
                            <?php $__env->startComponent('components.card'); ?>
                            <?php $__env->slot('item',$item); ?>
                            
                            <?php $__env->slot('height','300px'); ?>
                            <?php echo $__env->renderComponent(); ?>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php if($general->id == 2): ?>
                
                
                
                
            <div class="row my-5">
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="col-md-4 mb-5">
                        <a href="<?php echo e(route('producto',['producto' => $item->id])); ?>" class=" " style="text-decoration: none; color: unset;">
                            <div class="card">
                                <div class="card-body text-center">
                                    <img class="img-fluid" src="<?php echo e(asset($item->image[0]['image'] ?? '')); ?>" alt="Card image cap">
                                </div>
                                <div class="card-footer text-center bg-white">
                                    <p class="m-0"><?php echo $item->subfamily->text{'title_'.App::getLocale()} ?? ''; ?></p>
                                    <h4 class="">
                                        <?php echo $item->text{'title_'.App::getLocale()} ?? ''; ?>

                                    </h4>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/page/productos/productos.blade.php ENDPATH**/ ?>