<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <a class="text-decoration-none " href="<?php echo e(route('config.index',$producto)); ?>"><< Volver</a>
        <form class="row my-5" method="POST" action="<?php echo e(route('config.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="order" name="product_id" value="<?php echo $producto; ?>" class="form-control">

            <div class="row mb-2"  >
                <div class="col-md-6 md-form">
                    <input type="text" name="tipo_es" placeholder="Tipo - español" class="form-control">
                </div>
                <div class="col-md-6 md-form">
                    <input type="text" name="tipo_en" placeholder="Tipo - ingles" class="form-control">
                </div>
                <div class="col-md-6 md-form">
                    <input type="text" name="title_es" placeholder="Titulo - español" class="form-control">
                </div>
                <div class="col-md-6 md-form">
                    <input type="text" name="title_en" placeholder="Titulo - ingles" class="form-control">
                </div>
                <div class="md-form col-md-6">
                    <h6>Texto - español</h6>
                    <textarea id="text_es" class="md-textarea form-control" name="text_es" rows="3"></textarea>
                </div>
                <div class="md-form col-md-6">
                    <h6>Texto - ingles</h6>
                    <textarea id="text_en" class="md-textarea form-control" name="text_en" rows="3"></textarea>
                </div>
                <div class="col-md-6">
                    
                    <multiple-component :related="<?php echo e(json_encode($dosificadoras)); ?>"></multiple-component>
                </div>
                <div class="col-md-6 md-form">
                    <input type="text" name="order"   placeholder="Orden" class="form-control">
                </div>
            </div>
            <gallery-component></gallery-component>
            <div class="col-md-12 my-4 text-right">
                <button type="submit" class="btn btn-success">Guardar</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        CKEDITOR.replace('text_es');
        CKEDITOR.replace('text_en');

        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/adm/products/config/create.blade.php ENDPATH**/ ?>