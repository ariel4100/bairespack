<?php $__env->startPush('style'); ?>
    <style>
        #myClassicTab .nav-link{
            color: #000 !important;
        }
        #myClassicTab li .active{
            border-bottom: 2px solid #FFB900 !important;
        }
        #myClassicTab li a{
            border-bottom: 2px solid #B0B0B0;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" style="margin-top: 8rem">
        <div class="row">
            <div class="col-md-12">
                <h2 class="py-2" style="border-bottom: 2px solid #FEB80B; width: 100px">Videos</h2>
            </div>
        </div>
    </div>
    <!-- Classic tabs -->
    <div class="container my-4">
        <div class="classic-tabs">
            
            <ul class="nav mb-5" id="myClassicTab" role="tablist">
                <li class="nav-item">
                    <a class="nav-link px-5  waves-light active show" id="profile-tab-classic" data-toggle="tab" href="#video-0"
                       role="tab" aria-controls="profile-classic" aria-selected="true">Todos</a>
                </li>
                <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="nav-item">
                        <a class="nav-link px-5  waves-light  show" id="profile-tab-classic" data-toggle="tab" href="#video-<?php echo e($k+1); ?>"
                           role="tab" aria-controls="profile-classic" aria-selected="true"><?php echo $item->text{'title_'.App::getLocale()}; ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="nav-item">
                        <a class="nav-link  waves-light active show" id="profile-tab-classic" data-toggle="tab" href="#video"
                           role="tab" aria-controls="profile-classic" aria-selected="true">Todos</a>
                    </li>
                <?php endif; ?>
            </ul>
            <div class="tab-content" id="myClassicTabContent">
                <div class="tab-pane fade active  show" id="video-0" role="tabpanel" aria-labelledby="profile-tab-classic">
                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            
                            <?php $__empty_2 = true; $__currentLoopData = $item->video ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <div class="col-md-4 mb-4">
                                    <iframe width="100%" height="200" src="https://www.youtube.com/embed/<?php echo e($video{'video'} ?? ''); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                    <p><?php echo $video{'title_'.App::getLocale()} ?? ''; ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <p>No hay registro</p>
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h4 class="">No hay videos </h4>
                        <?php endif; ?>

                    </div>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="tab-pane fade  show" id="video-<?php echo e($k+1); ?>" role="tabpanel" aria-labelledby="profile-tab-classic">
                        <div class="row">
                            
                            <?php $__empty_2 = true; $__currentLoopData = $item->video ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <div class="col-md-4 mb-4">
                                <iframe width="100%" height="200" src="https://www.youtube.com/embed/<?php echo e($video{'video'} ?? ''); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                <p><?php echo $video{'title_'.App::getLocale()} ?? ''; ?></p>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <p>No hay registro</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h4 class="">No hay videos </h4>
                <?php endif; ?>
            </div>

        </div>
    </div>
    <!-- Classic tabs -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/page/videos.blade.php ENDPATH**/ ?>