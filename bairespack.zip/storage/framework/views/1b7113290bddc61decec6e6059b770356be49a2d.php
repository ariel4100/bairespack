<?php $__env->startPush('style'); ?>
    <style>
        .card{
            border-top: unset;
            transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out,-webkit-box-shadow .15s ease-in-out;
            /*color: #000000 !important;*/
        }
        .card:hover{
            border-top: unset;
            -webkit-box-shadow: 0 5px 11px 0 rgba(0,0,0,.18), 0 4px 15px 0 rgba(0,0,0,.15);
            box-shadow: 0 5px 11px 0 rgba(0,0,0,.18), 0 4px 15px 0 rgba(0,0,0,.15) !important;
            /*color: #000000 !important;*/
        }
    </style>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top: 8rem">
    <h2 class="text-uppercase">Noticias</h2>
    <hr align="left" class="" style="border-top: 2px solid #FEB80B; width: 150px">
    <div class="row my-5">
        <div class="col-md-8">
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-6 mb-5 wow fadeIn">
                        <a href="<?php echo e(route('noticias_blog',$n)); ?>" class="" style="text-decoration: none; color: unset;">
                            <div class="card shadow-none">
                                <img src="<?php echo e(asset($n->image[0]{'image'})); ?>" alt="" class="img-fluid">
                                <div class="card-footer" style="background-color: unset; height: 170px">
                                    <span class="baires-fondo badge text-uppercase p-2 my-2"><?php echo $n->Category->text{'title_es'}; ?></span>
                                    <h5 class="tpn-blue font-weight-bold"><?php echo $n->text{'title_es'}; ?></h5>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h4>No hay registros</h4>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-4 wow fadeIn">
            <div class="p-5" style="background-color: #F9F9F9">
                <h5 class="text-uppercase">Categorías</h5>
                <hr align="left" class="" style="background-color: #595959; width: 70px">
                <?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <p class="m-0"><a href="<?php echo e(route('show_noticias',$c->id)); ?>" class="" style="text-decoration: none; color: unset;"> <?php echo $c->text{'title_es'}; ?></a></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No hay registros</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/page/noticias/show_noticias.blade.php ENDPATH**/ ?>