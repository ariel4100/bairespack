<?php $__env->startSection('content'); ?>
<div class="container h-100 d-flex justify-content-center align-items-center">
<h1 class="my-5 animated  zoomIn">Bienvenido</h1>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/adm/dashboard/index.blade.php ENDPATH**/ ?>