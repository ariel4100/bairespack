<div class="fixed-top">
    
        
            
                
                    
                    
                    
                        
                            
                        
                    
                
            
        
    

    <nav class="navbar navbar-expand-lg navbar-light py-0" style="box-shadow: unset;">
        <div class="container" style="background-color: #333333">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset($logos->text{'header'})); ?>" alt="" class="img-fluid"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                    aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse flex-md-column" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="text-white ml-2" href=" "> <i class="fab fa-whatsapp mr-2" style="color: #25d366;"></i>54 9 11 6050-7809</a></li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <button class="btn btn-sm m-0 p-0 ml-2 text-white dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo e(App::getLocale()); ?>

                            </button>
                            <div class="dropdown-menu m-0 py-0 dropdown-menu-right" style="min-width: 2rem" aria-labelledby="dropdownMenuButton">
                                <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="dropdown-item m-0 p-0 <?php echo e(LaravelLocalization::getCurrentLocale()==$key?'active':''); ?>" href="<?php echo e(LaravelLocalization::getLocalizedURL($key)); ?>"><?php echo e(ucwords($key)); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>








                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link  ml-2 <?php echo e(request()->is('nosotros') ? 'activo' : ''); ?>" href="<?php echo e(route('nosotros')); ?>">Nosotros</a></li>
                    <li class="nav-item"><a class="nav-link  ml-2 <?php echo e(request()->is('productos/1*') ? 'activo' : ''); ?>" href="<?php echo e(route('productos',['general' => 1])); ?>">Envasadoras</a></li>
                    <li class="nav-item"><a class="nav-link  ml-2 <?php echo e(request()->is('productos/2*') ? 'activo' : ''); ?>" href="<?php echo e(route('productos',['general' => 2])); ?>">Dosificadoras</a></li>
                    <li class="nav-item"><a class="nav-link  ml-2 <?php echo e(request()->is('productos/3*') ? 'activo' : ''); ?>" href="<?php echo e(route('productos',['general' => 3])); ?>">Accesorios</a></li>
                    <li class="nav-item"><a class="nav-link  ml-2 <?php echo e(request()->is('noticias') ? 'activo' : ''); ?>" href="<?php echo e(route('noticias')); ?>">Noticias</a></li>
                    <li class="nav-item"><a class="nav-link  ml-2 <?php echo e(request()->is('post-venta') ? 'activo' : ''); ?>" href="<?php echo e(route('post.venta')); ?>">Post-Venta</a></li>
                    <li class="nav-item"><a class="nav-link  ml-2 <?php echo e(request()->is('videos') ? 'activo' : ''); ?>" href="<?php echo e(route('videos')); ?>">Videos</a></li>
                    <li class="nav-item"><a class="nav-link  ml-2 <?php echo e(request()->is('contacto') ? 'activo' : ''); ?>" href="<?php echo e(route('contacto')); ?>">Contacto</a></li>
                    <li class="nav-item"><a class="nav-link  ml-2" href=" "><i class="fas fa-search prefix rounded-pill p-1 baires-color"  style="border: 2px solid #FEB80B;"></i></a></li>
                </ul>
            </div>
        </div>
    </nav>
</div><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/page/partials/header.blade.php ENDPATH**/ ?>