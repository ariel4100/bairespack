<div class="container" style="margin-top: 8rem">
    <div class="row">
        <div class="col-md-12">
            <h2 class="py-2" style="border-bottom: 2px solid #FEB80B; width: 20%"><?php echo e($title); ?></h2>

        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/components/title.blade.php ENDPATH**/ ?>