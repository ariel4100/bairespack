<?php $__env->startSection('content'); ?>
    <div class="container " style="margin-top: 8rem">
        
        <?php if($general->id == 1): ?>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="baires-color">Descubrí la máquina <br>
                        detrás de cada tipo de envase</h2>
                </div>
            </div>
            <div class="row mt-5">
                <?php $__currentLoopData = $family; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 mb-5">
                        <!-- Card -->

                            <div class="card shadow-none">
                                <a href="<?php echo e(route('subfamilia',['familia' => $item->id])); ?>" class="text-decoration-none" style="color: unset;">
                                    <div class="card-header border-top border-bottom-0 bg-white">
                                        <p class="text-center m-0"><?php echo $item->general->text{'title_es'}; ?></p>
                                        <h4 class="text-center">
                                            <?php echo $item->text{'title_es'}; ?>

                                        </h4>
                                    </div>

                                    <!-- Card content -->
                                    <div class="card-body d-flex align-items-center" style="height: 300px">
                                        <!-- Card image -->
                                        <img class="img-fluid" src="<?php echo e(asset($item->text{'image'})); ?>" alt="Card image cap" style="">

                                    </div>
                                </a>
                                <?php $__env->startComponent('components.gallery'); ?>
                                <?php $__env->slot('gallery',$item->image); ?>
                                <?php $__env->slot('id',$item->id); ?>
                                <?php echo $__env->renderComponent(); ?>
                                <div class="card-footer border-0 bg-white">
                                    <p class="m-0 text-center">Tipo</p>
                                    <h4 class="text-center">
                                        <?php echo $item->text{'type_es'}; ?>

                                    </h4>
                                </div>
                            </div>

                        <!-- Card -->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        
        <?php if($general->id == 2): ?>
        <div class="row">
            <div class="col-md-12">
                <h2 class="baires-color">Seleccioná una dosificadora</h2>
            </div>
        </div>

        <div class="row mt-5">
            <?php $__currentLoopData = $family; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-5">
                    <a href="<?php echo e(route('subfamilia',['familia' => $item->id])); ?>" class="text-decoration-none" style="color: unset;">
                        <?php $__env->startComponent('components.card'); ?>
                        <?php $__env->slot('item',$item); ?>
                        <?php $__env->slot('height','200px'); ?>
                        <?php echo $__env->renderComponent(); ?>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

        
        <?php if($general->id == 3): ?>
            
            <div class="row">
                <div class="col-md-12">
                    <h2 class="baires-color">Seleccioná un Accesorio</h2>
                </div>
            </div>
            <div class="row mt-5">
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    

                    <div class="col-md-4 mb-5">
                        <a href="<?php echo e(route('producto',['producto' => $item->id])); ?>" class=" " style="text-decoration: none; color: unset;">
                            <?php $__env->startComponent('components.card'); ?>
                            <?php $__env->slot('item',$item); ?>

                            <?php $__env->slot('height','200px'); ?>
                            <?php echo $__env->renderComponent(); ?>
                            
                                
                                    
                                
                                
                                    
                                    
                                        
                                    
                                
                            
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/page/productos/categorias.blade.php ENDPATH**/ ?>