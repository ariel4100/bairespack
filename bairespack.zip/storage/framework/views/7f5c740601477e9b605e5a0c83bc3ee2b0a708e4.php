<?php $__env->startSection('content'); ?>
    <div class="container p-4">
        <gallery-component></gallery-component>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        CKEDITOR.replace('text');

        CKEDITOR.config.width = '100%';
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adm.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ariel\nuevos\bairespack\resources\views/adm/content/lista.blade.php ENDPATH**/ ?>